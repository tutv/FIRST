'use strict';

const Auth = require('./plugins/auth');

module.exports = [
    Auth
];
package com.fries.hkt.event.eventhackathon.eventbus;

/**
 * Created by hungtran on 3/11/17.
 */

public class ShowQuickAnswerEvent {
}

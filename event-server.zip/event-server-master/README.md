# API for công cụ quản lí event hàng đầu Việt Nam

`.env`

```
SERVER_ADDRESS=localhost
SERVER_PORT=9696
SERVER_KEY=com.fries
SERVER_HOST=https://b5ffd7e9.ngrok.io

MONGODB_URI=127.0.0.1:27017/event

FB_APP_ID=117017202161770
FB_APP_SECRET=d9bd8fbd01447734e90c4f59fc3364c1
```
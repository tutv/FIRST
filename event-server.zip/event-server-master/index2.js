'use strict';

const schedule = require('./scheduler/check-event');

schedule();
'use strict';

module.exports = {
    user : require('./user'),
    upload : require('./upload'),
    event : require('./event')
};

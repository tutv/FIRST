# utils
Chứa các công cụ làm nhiệm vụ: 
    
    - I/O 
    - Helper cho SQLite 
    - Preferences
    - CommonValues 
    - ...
package com.fries.hkt.event.eventhackathon.customview;

import android.content.Context;
import android.widget.LinearLayout;

/**
 * Created by hungtran on 3/11/17.
 */

public class QuickAnswerViewGroup extends LinearLayout{
    public QuickAnswerViewGroup(Context context) {
        super(context);
    }
}

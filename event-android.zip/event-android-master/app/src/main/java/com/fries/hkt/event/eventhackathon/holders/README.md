# holders
Chứa các Holder cho RecycleView
package com.fries.hkt.event.eventhackathon.app;

/**
 * Created by tmq on 11/03/2017.
 */

public class AppConfig {

    public static final String BASE_URL = "https://event.edoo.vn";


    public static final String REGISTER_FCM = BASE_URL + "/fcm";


}
